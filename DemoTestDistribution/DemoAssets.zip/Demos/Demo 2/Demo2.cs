using System.Collections;
using Chobitech.DemoKit;
using UnityEngine;

public class Demo2 : CoroutineDemoBase
{
    [SerializeField]
    private DemoSphere demoSphere;

    [SerializeField]
    private float durationSec = 2f;

    public override IEnumerator DemoRoutine()
    {
        if (demoSphere == null)
        {
            AddLogLnWithColorTag("error", "DemoSphere is not set");
            yield break;
        }

        if (durationSec <= 0)
        {
            AddLogLnWithColorTag("error", "The animation duration sec is invalid.");
            yield break;
        }

        AddLogLnWithColorTag("warning", "Starting Demo 2: Inheriting <b>CoroutineDemoBase</b>");

        demoSphere.SelfTransform.localPosition = Vector3.zero;

        var elapsedTime = 0f;
        while (elapsedTime < durationSec)
        {
            var y = 3 * Mathf.Sin(Mathf.PI * 2 * elapsedTime / durationSec);

            var pos = new Vector3(0, y, 0);

            demoSphere.SelfTransform.localPosition = pos;

            AddLogLn($"y = {y}");

            elapsedTime += Time.deltaTime;

            yield return null;
        }

        demoSphere.SelfTransform.localPosition = Vector3.zero;

        AddLogLnWithColorTag("warning", "Demo 2 finished.");
    }
}
