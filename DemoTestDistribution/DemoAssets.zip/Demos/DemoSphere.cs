using UnityEditor;
using UnityEngine;

[RequireComponent(typeof(Renderer))]
public class DemoSphere : MonoBehaviour
{

    public Transform SelfTransform { get; private set; }

    [SerializeField]
    private Color sphereColor = Color.white;

    private Renderer _renderer;

    private MaterialPropertyBlock _mpb;

    public void SetColor(Color color)
    {
        if (_renderer == null)
        {
            return;
        }

        _mpb.SetColor("_Color", color);
        _renderer.SetPropertyBlock(_mpb);
    }

    private void InitDemoSphere()
    {
        _renderer = GetComponent<Renderer>();

        _mpb ??= new();
        
        if (_renderer != null)
        {
            _renderer.GetPropertyBlock(_mpb);
            SetColor(sphereColor);
        }
    }

#if UNITY_EDITOR
    void OnValidate()
    {
        if (!Application.isPlaying && !EditorApplication.isPlayingOrWillChangePlaymode)
        {
            InitDemoSphere();
        }
    }
#endif


    void Awake()
    {
        SelfTransform = transform;

        InitDemoSphere();
    }
}
