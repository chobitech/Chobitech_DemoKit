using System.Threading;
using System.Threading.Tasks;
using Chobitech.DemoKit;
using UnityEngine;

public class Demo1 : AsyncDemoBase
{
    [SerializeField]
    private DemoSphere demoSphere;

    [SerializeField]
    private float durationSec = 2f;

    public override void OnDemoCanceled(CancellationToken token)
    {
        base.OnDemoCanceled(token);
    }

    public override async Task DemoProcessAsync(CancellationToken token)
    {
        if (demoSphere == null)
        {
            AddLogLnWithColorTag("error", "DemoSphere is not set");
            return;
        }

        if (durationSec <= 0)
        {
            AddLogLnWithColorTag("error", "The animation duration sec is invalid.");
            return;
        }

        AddLogLnWithColorTag("notice", "Starting Demo 1: Inheriting <b>AsyncDemoBase</b>");

        demoSphere.SelfTransform.localPosition = Vector3.zero;

        var elapsedTime = 0f;
        while (elapsedTime < durationSec)
        {
            token.ThrowIfCancellationRequested();

            var x = 3 * Mathf.Sin(Mathf.PI * 2 * elapsedTime / durationSec);

            demoSphere.SelfTransform.localPosition = new(x, 0, 0);

            AddLogLn($"x = {x}");

            elapsedTime += Time.deltaTime;
            
            token.ThrowIfCancellationRequested();

            await Task.Yield();
        }

        demoSphere.SelfTransform.localPosition = Vector3.zero;

        AddLogLnWithColorTag("notice", "Demo 1 finished.");
    }
}
